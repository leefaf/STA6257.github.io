# This folder contains the Rmd template for project report:

  -**Template_Report.Rmd**
  
  -**Template_Report.html**
  
  -**Template_Report.pdf**
  
  -**references.bib**
