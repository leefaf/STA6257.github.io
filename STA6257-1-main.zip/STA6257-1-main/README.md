# Welcome to STA6257 - Advanced Stats Modeling!

This repository contains material for Advanced Stats Modeling course as follows:

1. Rmd template for project report
2. R scripts for practice assignments

