# This file contains the following R codes:

1. **Tidyverse.R** : Introduction to Tidyverse and data management using R.
2. **NormalLinearModels.R**: Fit Normal Linear regression, CIs, Diganostics, ANOVA, Weighted Regression, Predictions.
